from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bsky_collector_v2.fs_utils import atomic_write_json, ensure_dir
from bsky_collector_v2.http_client import AsyncHttpClient, HttpRetryConfig, XrpcHosts
from bsky_collector_v2.layout import Layout
from bsky_collector_v2.manifest import git_sha
from bsky_collector_v2.progress import ProgressReporter, ProgressState
from bsky_collector_v2.state import ControlState
from bsky_collector_v2.time_utils import format_utc, now_utc, utc_date_str
from bsky_collector_v2.types import FeedUri, RunId
from bsky_collector_v2.writers import CsvPartWriter

logger = logging.getLogger("bsky_collector_v2.job.index_feed_generators")


@dataclass(frozen=True)
class FeedGeneratorsIndexCheckpoint:
    cursor: str | None
    page_index: int
    done: bool
    updated_at_utc: str

    @classmethod
    def initial(cls, *, started_at_utc: str) -> "FeedGeneratorsIndexCheckpoint":
        return cls(cursor=None, page_index=0, done=False, updated_at_utc=started_at_utc)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FeedGeneratorsIndexCheckpoint":
        cursor = data.get("cursor")
        cursor_out = str(cursor) if isinstance(cursor, str) and cursor else None
        page_index = int(data.get("page_index") or 0)
        done = bool(data.get("done") is True)
        updated = data.get("updated_at_utc")
        updated_out = str(updated) if isinstance(updated, str) and updated else format_utc(now_utc())
        return cls(cursor=cursor_out, page_index=page_index, done=done, updated_at_utc=updated_out)

    def to_dict(self) -> dict[str, Any]:
        return {
            "cursor": self.cursor,
            "page_index": int(self.page_index),
            "done": bool(self.done),
            "updated_at_utc": str(self.updated_at_utc),
        }


def _load_checkpoint(path: Path) -> FeedGeneratorsIndexCheckpoint | None:
    if not path.exists():
        return None
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError:
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    try:
        return FeedGeneratorsIndexCheckpoint.from_dict(data)
    except Exception:  # noqa: BLE001
        return None


def _write_checkpoint(path: Path, cp: FeedGeneratorsIndexCheckpoint) -> None:
    atomic_write_json(path, cp.to_dict())


def _find_existing_part(layout: Layout, *, page_index: int) -> Path | None:
    root = layout.metadata_root
    if not root.exists():
        return None
    name = f"feed_generators_part_{int(page_index):06d}.jsonl"
    # Small N (two-week run); scan newest-first to find recent files quickly.
    days = sorted([p for p in root.iterdir() if p.is_dir() and len(p.name) == 10], reverse=True)
    for day in days:
        cand = day / "feed_generators_index" / "parts" / name
        if cand.exists():
            return cand
    return None


def _read_part_meta(path: Path) -> dict[str, Any] | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            last: str | None = None
            for line in f:
                if line.strip():
                    last = line
    except OSError:
        return None
    if not last:
        return None
    try:
        obj = json.loads(last)
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict) or obj.get("__meta__") is not True:
        return None
    return obj


def _load_or_init_day_manifest(
    *,
    manifest_path: Path,
    resume: bool,
    started_at_utc: str,
    repo_root: Path,
    params: dict[str, Any],
) -> RunId:
    existing: dict[str, Any] | None = None
    if manifest_path.exists():
        try:
            loaded = json.loads(manifest_path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                existing = loaded
        except Exception:  # noqa: BLE001
            existing = None

    run_id: str | None = None
    if resume and existing is not None:
        rid = existing.get("run_id")
        if isinstance(rid, str) and rid:
            run_id = rid

    from bsky_collector_v2.manifest import new_run_id

    if not run_id:
        run_id = str(new_run_id())

    manifest: dict[str, Any] = dict(existing or {})
    prior_started = manifest.get("started_at_utc")
    manifest_started = prior_started if isinstance(prior_started, str) and prior_started else started_at_utc
    manifest.update(
        {
            "run_id": run_id,
            "job_name": "index-feed-generators",
            "date_utc": manifest.get("date_utc") or utc_date_str(now_utc()),
            "started_at_utc": manifest_started,
            "git_sha": manifest.get("git_sha") or git_sha(repo_root),
            "params": dict(params),
        }
    )
    atomic_write_json(manifest_path, manifest)
    return RunId(run_id)


def _finish_day_manifest(
    path: Path,
    *,
    success: bool,
    error: str | None,
    extra: dict[str, Any] | None,
) -> None:
    existing: dict[str, Any] | None = None
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                existing = loaded
        except Exception:  # noqa: BLE001
            existing = None
    manifest: dict[str, Any] = dict(existing or {})
    manifest["finished_at_utc"] = format_utc(now_utc())
    manifest["success"] = bool(success)
    if error:
        manifest["error"] = str(error)
    if extra:
        manifest.update({str(k): v for k, v in extra.items()})
    atomic_write_json(path, manifest)


async def run_index_feed_generators(
    *,
    layout: Layout,
    repo_root: Path,
    hosts: XrpcHosts,
    rps: float,
    time_budget_minutes: int,
    resume: bool,
    dry_run: bool,
    accept_language: str | None,
    accept_labelers: str | None,
    vantage_id: str,
) -> None:
    date_str = utc_date_str(now_utc())
    day_dir = layout.feed_generators_index_day_dir(date_str)
    if dry_run:
        logger.info("dry_run=true: would index feed generators date=%s out=%s", date_str, str(day_dir))
        return

    ensure_dir(layout.feed_generators_index_parts_dir(date_str))
    ensure_dir(layout.feed_generators_index_logs_dir(date_str))

    started_at_utc = format_utc(now_utc())
    run_id = _load_or_init_day_manifest(
        manifest_path=layout.feed_generators_index_manifest_json(date_str),
        resume=resume,
        started_at_utc=started_at_utc,
        repo_root=repo_root,
        params={
            "date_utc": date_str,
            "rps": float(rps),
            "time_budget_minutes": int(time_budget_minutes),
            "resume": bool(resume),
            "accept_language": accept_language,
            "accept_labelers": accept_labelers,
            "vantage_id": str(vantage_id).strip() or "unauth",
        },
    )

    progress = ProgressState(job_name="index-feed-generators", run_id=run_id, started_at_utc=started_at_utc)
    progress.rps_config = float(rps)
    progress.concurrency = 1
    reporter = ProgressReporter(layout.feed_generators_index_progress_json(date_str), progress, write_interval_s=15.0)
    reporter.start()

    http_stats_writer = CsvPartWriter(
        layout.feed_generators_index_http_stats_csv(date_str),
        fieldnames=["timestamp_utc", "endpoint", "status_code", "latency_ms", "attempt", "error_type", "feed_uri"],
        flush_interval_s=2.0,
        fsync_interval_s=10.0,
    )

    http = AsyncHttpClient(
        hosts=hosts,
        rps=rps,
        retry=HttpRetryConfig(max_retries=2),
        timeout_s=30.0,
        http_stats=http_stats_writer,
        progress=progress,
        accept_language=accept_language,
        accept_labelers=accept_labelers,
    )

    success = False
    error: str | None = None
    try:
        with ControlState.open(layout.control_db_path) as state:
            state.start_run(
                run_id=run_id,
                job_name="index-feed-generators",
                started_at_utc=started_at_utc,
                params={
                    "date_utc": date_str,
                    "time_budget_minutes": int(time_budget_minutes),
                },
            )
            try:
                checkpoint_path = layout.feed_generators_index_checkpoint_json
                cp = _load_checkpoint(checkpoint_path) if resume else None
                if cp is None:
                    cp = FeedGeneratorsIndexCheckpoint.initial(started_at_utc=started_at_utc)

                # Repair/advance if a completed part exists but checkpoint didn't advance (crash between file+checkpoint).
                while True:
                    existing_part = _find_existing_part(layout, page_index=cp.page_index)
                    if existing_part is None:
                        break
                    meta = _read_part_meta(existing_part)
                    if not meta:
                        break
                    next_cursor = meta.get("page_next_cursor")
                    next_cursor_out = str(next_cursor) if isinstance(next_cursor, str) and next_cursor else None
                    logger.info(
                        "repairing checkpoint from existing part page_index=%s part=%s",
                        int(cp.page_index),
                        str(existing_part),
                    )
                    cp = FeedGeneratorsIndexCheckpoint(
                        cursor=next_cursor_out,
                        page_index=int(cp.page_index) + 1,
                        done=bool(next_cursor_out is None),
                        updated_at_utc=format_utc(now_utc()),
                    )
                    _write_checkpoint(checkpoint_path, cp)
                    if cp.done:
                        break

                if cp.done:
                    logger.info("index already complete cursor=None page_index=%s; nothing to do", int(cp.page_index))
                    from bsky_collector_v2.jobs.refresh_discovery import _export_feed_catalog_csv

                    _export_feed_catalog_csv(state=state, out_csv=layout.feed_catalog_csv(date_str))
                    success = True
                    return

                deadline_s = time.monotonic() + max(1, int(time_budget_minutes)) * 60.0
                pages_written = 0
                feeds_written = 0

                while time.monotonic() < (deadline_s - 2.0):
                    captured_at_utc = format_utc(now_utc())
                    start_cursor = cp.cursor
                    page_index = int(cp.page_index)

                    params: dict[str, Any] = {"limit": 100}
                    if start_cursor:
                        params["cursor"] = start_cursor

                    resp = await http.xrpc_get(
                        endpoint="app.bsky.unspecced.getPopularFeedGenerators",
                        host=http.hosts.appview_host,
                        method="app.bsky.unspecced.getPopularFeedGenerators",
                        params=params,
                        access_jwt=None,
                        feed_uri=None,
                        timestamp_utc=captured_at_utc,
                    )
                    feeds = resp.data.get("feeds")
                    if not isinstance(feeds, list):
                        raise RuntimeError("getPopularFeedGenerators missing feeds[]")

                    next_cursor = resp.data.get("cursor") if isinstance(resp.data.get("cursor"), str) else None

                    # Upsert to feed_catalog first so any visible part implies state was committed.
                    n_this_page = 0
                    for item in feeds:
                        if not isinstance(item, dict):
                            continue
                        uri = item.get("uri")
                        if not isinstance(uri, str) or not uri:
                            continue
                        creator_did = None
                        creator = item.get("creator")
                        if isinstance(creator, dict) and isinstance(creator.get("did"), str):
                            creator_did = str(creator.get("did"))
                        service_did = item.get("did") if isinstance(item.get("did"), str) else None
                        like_count = item.get("likeCount") if isinstance(item.get("likeCount"), int) else None
                        provider_domain = None
                        if service_did and service_did.startswith("did:web:"):
                            provider_domain = service_did.removeprefix("did:web:") or None
                        state.upsert_feed_catalog(
                            feed_uri=FeedUri(uri),
                            creator_did=creator_did,
                            service_did=service_did,
                            provider_domain=provider_domain,
                            like_count_last=like_count,
                            discovered_from=["feed_generators_index"],
                            seen_at_utc=captured_at_utc,
                        )
                        n_this_page += 1
                    state.commit()

                    part_dir = layout.feed_generators_index_parts_dir(date_str)
                    part_path = part_dir / f"feed_generators_part_{page_index:06d}.jsonl"
                    if part_path.exists():
                        raise RuntimeError(f"refusing to overwrite existing part file: {part_path} (use --resume)")
                    tmp_path = part_path.with_name(part_path.name + ".tmp")
                    ensure_dir(part_dir)
                    payload_lines: list[str] = []
                    for pos, item in enumerate(feeds):
                        if not isinstance(item, dict):
                            continue
                        payload_lines.append(
                            json.dumps(
                                {
                                    "captured_at_utc": captured_at_utc,
                                    "page_index": page_index,
                                    "page_start_cursor": start_cursor,
                                    "position": pos,
                                    "item": item,
                                },
                                ensure_ascii=False,
                            )
                        )
                    payload_lines.append(
                        json.dumps(
                            {
                                "__meta__": True,
                                "captured_at_utc": captured_at_utc,
                                "page_index": page_index,
                                "page_start_cursor": start_cursor,
                                "page_next_cursor": next_cursor,
                                "n_items": int(n_this_page),
                            },
                            ensure_ascii=False,
                        )
                    )
                    payload = "\n".join(payload_lines) + "\n"
                    with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
                        f.write(payload)
                        f.flush()
                        os.fsync(f.fileno())
                    os.replace(tmp_path, part_path)

                    cp = FeedGeneratorsIndexCheckpoint(
                        cursor=next_cursor,
                        page_index=page_index + 1,
                        done=bool(next_cursor is None),
                        updated_at_utc=format_utc(now_utc()),
                    )
                    _write_checkpoint(checkpoint_path, cp)

                    pages_written += 1
                    feeds_written += int(n_this_page)
                    progress.feeds_done += int(n_this_page)
                    logger.info(
                        "indexed feed generators page=%s feeds=%s next_cursor=%s",
                        page_index,
                        int(n_this_page),
                        "none" if next_cursor is None else "set",
                    )

                    if cp.done:
                        logger.info("index complete pages=%s feeds=%s", pages_written, feeds_written)
                        break

                # Publish an updated feed_catalog.csv snapshot under today's metadata for downstream jobs.
                from bsky_collector_v2.jobs.refresh_discovery import _export_feed_catalog_csv

                _export_feed_catalog_csv(state=state, out_csv=layout.feed_catalog_csv(date_str))

                success = True
            finally:
                state.finish_run(run_id=run_id, finished_at_utc=format_utc(now_utc()), success=success)
    except Exception as err:  # noqa: BLE001
        error = repr(err)
        raise
    finally:
        try:
            await http.aclose()
        finally:
            http_stats_writer.close()
            reporter.stop()
            _finish_day_manifest(
                layout.feed_generators_index_manifest_json(date_str),
                success=success,
                error=error,
                extra=None,
            )

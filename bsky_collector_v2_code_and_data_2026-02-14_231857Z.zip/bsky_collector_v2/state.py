from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

from bsky_collector_v2.types import FeedUri, PostUri, RunId, ViewerMode


def _connect_sqlite(path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    conn.execute("PRAGMA foreign_keys=ON;")
    conn.execute("PRAGMA busy_timeout=5000;")
    conn.commit()
    return conn


@dataclass(frozen=True)
class ControlState:
    path: Path
    conn: sqlite3.Connection

    @staticmethod
    def open(path: Path) -> "ControlState":
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = _connect_sqlite(path)
        state = ControlState(path=path, conn=conn)
        state.init_schema()
        return state

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "ControlState":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        self.close()

    def init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS feed_catalog (
              feed_uri TEXT PRIMARY KEY,
              creator_did TEXT,
              service_did TEXT,
              provider_domain TEXT,
              like_count_last INTEGER,
              discovered_from TEXT NOT NULL,
              first_seen_utc TEXT NOT NULL,
              last_seen_utc TEXT NOT NULL,
              last_hydrated_utc TEXT
            );

            CREATE TABLE IF NOT EXISTS post_registry (
              post_uri TEXT PRIMARY KEY,
              first_seen_utc TEXT NOT NULL,
              last_seen_utc TEXT NOT NULL,
              seen_count INTEGER NOT NULL,
              first_written INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS queue_posts (
              post_uri TEXT PRIMARY KEY,
              first_seen_utc TEXT NOT NULL,
              priority INTEGER NOT NULL,
              status_likes TEXT,
              status_reposts TEXT,
              status_quotes TEXT,
              status_replies TEXT,
              last_error TEXT,
              updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS runs (
              run_id TEXT PRIMARY KEY,
              job_name TEXT NOT NULL,
              started_at_utc TEXT NOT NULL,
              finished_at_utc TEXT,
              params_json TEXT NOT NULL,
              success INTEGER
            );

            CREATE TABLE IF NOT EXISTS author_registry (
              author_did TEXT PRIMARY KEY,
              first_seen_utc TEXT NOT NULL,
              last_seen_utc TEXT NOT NULL,
              seen_count INTEGER NOT NULL,
              last_hydrated_utc TEXT
            );

            CREATE TABLE IF NOT EXISTS wide_sweep_tasks (
              date_utc TEXT NOT NULL,
              feed_uri TEXT NOT NULL,
              status TEXT NOT NULL,
              attempts INTEGER NOT NULL,
              last_error TEXT,
              updated_at_utc TEXT NOT NULL,
              started_at_utc TEXT,
              finished_at_utc TEXT,
              PRIMARY KEY (date_utc, feed_uri)
            );

            -- Feed generator indexing state (daily, resumable, crash-safe).
            CREATE TABLE IF NOT EXISTS feed_generator_index_global (
              collection TEXT PRIMARY KEY,
              repo_source TEXT NOT NULL,
              repos_cursor TEXT,
              repos_done INTEGER NOT NULL,
              updated_at_utc TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS feed_generator_index_repo_tasks (
              collection TEXT NOT NULL,
              repo_did TEXT NOT NULL,
              status TEXT NOT NULL,
              cursor TEXT,
              attempts INTEGER NOT NULL,
              last_error TEXT,
              first_seen_utc TEXT NOT NULL,
              updated_at_utc TEXT NOT NULL,
              PRIMARY KEY (collection, repo_did)
            );

            CREATE INDEX IF NOT EXISTS idx_fg_index_repo_status
              ON feed_generator_index_repo_tasks(collection, status, attempts, updated_at_utc);

            CREATE TABLE IF NOT EXISTS feed_generator_index_parts (
              collection TEXT NOT NULL,
              date_utc TEXT NOT NULL,
              part_index INTEGER NOT NULL,
              status TEXT NOT NULL,
              started_at_utc TEXT NOT NULL,
              finished_at_utc TEXT,
              n_records INTEGER NOT NULL,
              last_error TEXT,
              PRIMARY KEY (collection, date_utc, part_index)
            );
            """
        )
        self.conn.commit()

    def start_run(self, *, run_id: RunId, job_name: str, started_at_utc: str, params: dict[str, Any]) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO runs(run_id, job_name, started_at_utc, params_json, success)
            VALUES (?, ?, ?, ?, NULL)
            """,
            (str(run_id), job_name, started_at_utc, json.dumps(params, ensure_ascii=False, sort_keys=True)),
        )
        self.conn.commit()

    def finish_run(self, *, run_id: RunId, finished_at_utc: str, success: bool) -> None:
        self.conn.execute(
            "UPDATE runs SET finished_at_utc=?, success=? WHERE run_id=?",
            (finished_at_utc, 1 if success else 0, str(run_id)),
        )
        self.conn.commit()

    def upsert_feed_catalog(
        self,
        *,
        feed_uri: FeedUri,
        creator_did: str | None,
        service_did: str | None,
        provider_domain: str | None,
        like_count_last: int | None,
        discovered_from: Sequence[str],
        seen_at_utc: str,
    ) -> None:
        # Merge discovered_from sources so repeated discovery runs accumulate provenance.
        merged_sources = set(str(s) for s in discovered_from if str(s))
        row = self.conn.execute(
            "SELECT discovered_from FROM feed_catalog WHERE feed_uri=?",
            (str(feed_uri),),
        ).fetchone()
        if row is not None:
            raw = row["discovered_from"]
            if isinstance(raw, str) and raw:
                try:
                    prev = json.loads(raw)
                except json.JSONDecodeError:
                    prev = None
                if isinstance(prev, list):
                    merged_sources.update(str(s) for s in prev if isinstance(s, str) and s)

        self.conn.execute(
            """
            INSERT INTO feed_catalog(
              feed_uri, creator_did, service_did, provider_domain,
              like_count_last, discovered_from, first_seen_utc, last_seen_utc, last_hydrated_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL)
            ON CONFLICT(feed_uri) DO UPDATE SET
              creator_did = COALESCE(excluded.creator_did, feed_catalog.creator_did),
              service_did = COALESCE(excluded.service_did, feed_catalog.service_did),
              provider_domain = COALESCE(excluded.provider_domain, feed_catalog.provider_domain),
              like_count_last = COALESCE(excluded.like_count_last, feed_catalog.like_count_last),
              discovered_from = excluded.discovered_from,
              last_seen_utc = excluded.last_seen_utc
            """,
            (
                str(feed_uri),
                creator_did,
                service_did,
                provider_domain,
                like_count_last,
                json.dumps(sorted(merged_sources), ensure_ascii=False),
                seen_at_utc,
                seen_at_utc,
            ),
        )

    def commit(self) -> None:
        self.conn.commit()

    def iter_feed_catalog(self) -> Iterator[sqlite3.Row]:
        cur = self.conn.execute(
            """
            SELECT feed_uri, creator_did, service_did, provider_domain, like_count_last,
                   discovered_from, first_seen_utc, last_seen_utc, last_hydrated_utc
            FROM feed_catalog
            ORDER BY (like_count_last IS NULL) ASC, like_count_last DESC, feed_uri
            """
        )
        yield from cur

    def upsert_post_registry_many(self, *, post_uris: Sequence[PostUri], seen_at_utc: str) -> None:
        rows = [(str(p), seen_at_utc, seen_at_utc) for p in post_uris]
        self.conn.executemany(
            """
            INSERT INTO post_registry(post_uri, first_seen_utc, last_seen_utc, seen_count, first_written)
            VALUES (?, ?, ?, 1, 0)
            ON CONFLICT(post_uri) DO UPDATE SET
              last_seen_utc = excluded.last_seen_utc,
              seen_count = post_registry.seen_count + 1
            """,
            rows,
        )

    def select_not_written(self, *, post_uris: Sequence[PostUri]) -> list[PostUri]:
        if not post_uris:
            return []
        placeholders = ",".join("?" for _ in post_uris)
        cur = self.conn.execute(
            f"SELECT post_uri FROM post_registry WHERE post_uri IN ({placeholders}) AND first_written=0",
            tuple(str(p) for p in post_uris),
        )
        return [PostUri(str(r["post_uri"])) for r in cur.fetchall()]

    def mark_first_written(self, *, post_uris: Sequence[PostUri]) -> None:
        if not post_uris:
            return
        self.conn.executemany(
            "UPDATE post_registry SET first_written=1 WHERE post_uri=?",
            [(str(p),) for p in post_uris],
        )

    def upsert_author_registry_many(self, *, author_dids: Sequence[str], seen_at_utc: str) -> None:
        rows = [(str(d), seen_at_utc, seen_at_utc) for d in author_dids if str(d)]
        if not rows:
            return
        self.conn.executemany(
            """
            INSERT INTO author_registry(author_did, first_seen_utc, last_seen_utc, seen_count, last_hydrated_utc)
            VALUES (?, ?, ?, 1, NULL)
            ON CONFLICT(author_did) DO UPDATE SET
              last_seen_utc = excluded.last_seen_utc,
              seen_count = author_registry.seen_count + 1
            """,
            rows,
        )

    def select_authors_to_hydrate(self, *, limit: int) -> list[str]:
        cur = self.conn.execute(
            """
            SELECT author_did
            FROM author_registry
            WHERE last_hydrated_utc IS NULL
            ORDER BY first_seen_utc ASC
            LIMIT ?
            """,
            (int(limit),),
        )
        return [str(r["author_did"]) for r in cur.fetchall()]

    def mark_authors_hydrated(self, *, author_dids: Sequence[str], hydrated_at_utc: str) -> None:
        if not author_dids:
            return
        self.conn.executemany(
            "UPDATE author_registry SET last_hydrated_utc=? WHERE author_did=?",
            [(hydrated_at_utc, str(d)) for d in author_dids],
        )

    def ensure_wide_tasks(self, *, date_utc: str, feed_uris: Sequence[FeedUri], updated_at_utc: str) -> None:
        rows = [(date_utc, str(u), "pending", 0, None, updated_at_utc, None, None) for u in feed_uris]
        if not rows:
            return
        self.conn.executemany(
            """
            INSERT OR IGNORE INTO wide_sweep_tasks(
              date_utc, feed_uri, status, attempts, last_error, updated_at_utc, started_at_utc, finished_at_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )

    def wide_pending_tasks(self, *, date_utc: str, max_attempts: int) -> list[tuple[FeedUri, int, str]]:
        cur = self.conn.execute(
            """
            SELECT feed_uri, attempts, status
            FROM wide_sweep_tasks
            WHERE date_utc=? AND status IN ('pending','failed') AND attempts < ?
            ORDER BY attempts ASC, feed_uri ASC
            """,
            (date_utc, int(max_attempts)),
        )
        return [(FeedUri(str(r["feed_uri"])), int(r["attempts"]), str(r["status"])) for r in cur.fetchall()]

    def mark_wide_in_progress(self, *, date_utc: str, feed_uri: FeedUri, started_at_utc: str) -> str | None:
        row = self.conn.execute(
            "SELECT status FROM wide_sweep_tasks WHERE date_utc=? AND feed_uri=?",
            (date_utc, str(feed_uri)),
        ).fetchone()
        prev = str(row["status"]) if row is not None else None
        self.conn.execute(
            """
            UPDATE wide_sweep_tasks
            SET status='in_progress', attempts=attempts+1, updated_at_utc=?, started_at_utc=?
            WHERE date_utc=? AND feed_uri=?
            """,
            (started_at_utc, started_at_utc, date_utc, str(feed_uri)),
        )
        return prev

    def mark_wide_done(
        self,
        *,
        date_utc: str,
        feed_uri: FeedUri,
        success: bool,
        finished_at_utc: str,
        last_error: str | None,
    ) -> None:
        status = "success" if success else "failed"
        self.conn.execute(
            """
            UPDATE wide_sweep_tasks
            SET status=?, updated_at_utc=?, finished_at_utc=?, last_error=?
            WHERE date_utc=? AND feed_uri=?
            """,
            (status, finished_at_utc, finished_at_utc, last_error, date_utc, str(feed_uri)),
        )

    def count_wide_by_status(self, *, date_utc: str) -> dict[str, int]:
        cur = self.conn.execute(
            "SELECT status, COUNT(*) AS n FROM wide_sweep_tasks WHERE date_utc=? GROUP BY status",
            (date_utc,),
        )
        return {str(r["status"]): int(r["n"]) for r in cur.fetchall()}

    # ---- Feed generator index state (global, resumable) ----

    def ensure_feed_generator_index_global(
        self,
        *,
        collection: str,
        repo_source: str,
        updated_at_utc: str,
    ) -> None:
        self.conn.execute(
            """
            INSERT OR IGNORE INTO feed_generator_index_global(
              collection, repo_source, repos_cursor, repos_done, updated_at_utc
            )
            VALUES (?, ?, NULL, 0, ?)
            """,
            (str(collection), str(repo_source), str(updated_at_utc)),
        )

    def get_feed_generator_index_global(self, *, collection: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """
            SELECT collection, repo_source, repos_cursor, repos_done, updated_at_utc
            FROM feed_generator_index_global
            WHERE collection=?
            """,
            (str(collection),),
        ).fetchone()

    def update_feed_generator_index_global(
        self,
        *,
        collection: str,
        repo_source: str,
        repos_cursor: str | None,
        repos_done: bool,
        updated_at_utc: str,
    ) -> None:
        self.conn.execute(
            """
            INSERT INTO feed_generator_index_global(
              collection, repo_source, repos_cursor, repos_done, updated_at_utc
            )
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(collection) DO UPDATE SET
              repo_source = excluded.repo_source,
              repos_cursor = excluded.repos_cursor,
              repos_done = excluded.repos_done,
              updated_at_utc = excluded.updated_at_utc
            """,
            (
                str(collection),
                str(repo_source),
                repos_cursor,
                1 if repos_done else 0,
                str(updated_at_utc),
            ),
        )

    def reset_feed_generator_index_in_progress_to_pending(self, *, collection: str, updated_at_utc: str) -> int:
        cur = self.conn.execute(
            """
            UPDATE feed_generator_index_repo_tasks
            SET status='pending', updated_at_utc=?
            WHERE collection=? AND status='in_progress'
            """,
            (str(updated_at_utc), str(collection)),
        )
        return int(cur.rowcount)

    def ensure_feed_generator_index_repo_tasks(
        self,
        *,
        collection: str,
        repo_dids: Sequence[str],
        first_seen_utc: str,
        updated_at_utc: str,
    ) -> int:
        rows = [
            (str(collection), str(did), "pending", None, 0, None, str(first_seen_utc), str(updated_at_utc))
            for did in repo_dids
            if str(did)
        ]
        if not rows:
            return 0
        cur = self.conn.executemany(
            """
            INSERT OR IGNORE INTO feed_generator_index_repo_tasks(
              collection, repo_did, status, cursor, attempts, last_error, first_seen_utc, updated_at_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        return int(cur.rowcount)

    def next_feed_generator_index_repo_tasks(
        self,
        *,
        collection: str,
        limit: int,
        max_attempts: int,
    ) -> list[tuple[str, str | None, int]]:
        cur = self.conn.execute(
            """
            SELECT repo_did, cursor, attempts
            FROM feed_generator_index_repo_tasks
            WHERE collection=? AND status IN ('pending','failed') AND attempts < ?
            ORDER BY attempts ASC, updated_at_utc ASC, repo_did ASC
            LIMIT ?
            """,
            (str(collection), int(max_attempts), int(limit)),
        )
        out: list[tuple[str, str | None, int]] = []
        for r in cur.fetchall():
            cursor_raw = r["cursor"]
            cursor = str(cursor_raw) if isinstance(cursor_raw, str) and cursor_raw else None
            out.append((str(r["repo_did"]), cursor, int(r["attempts"])))
        return out

    def mark_feed_generator_index_repo_in_progress(
        self,
        *,
        collection: str,
        repo_did: str,
        started_at_utc: str,
    ) -> None:
        self.conn.execute(
            """
            UPDATE feed_generator_index_repo_tasks
            SET status='in_progress',
                attempts=attempts+1,
                updated_at_utc=?
            WHERE collection=? AND repo_did=?
            """,
            (str(started_at_utc), str(collection), str(repo_did)),
        )

    def mark_feed_generator_index_repo_done(
        self,
        *,
        collection: str,
        repo_did: str,
        status: str,
        cursor: str | None,
        updated_at_utc: str,
        last_error: str | None,
    ) -> None:
        self.conn.execute(
            """
            UPDATE feed_generator_index_repo_tasks
            SET status=?,
                cursor=?,
                last_error=?,
                updated_at_utc=?
            WHERE collection=? AND repo_did=?
            """,
            (str(status), cursor, last_error, str(updated_at_utc), str(collection), str(repo_did)),
        )

    def delete_feed_generator_index_repo_task(self, *, collection: str, repo_did: str) -> None:
        self.conn.execute(
            "DELETE FROM feed_generator_index_repo_tasks WHERE collection=? AND repo_did=?",
            (str(collection), str(repo_did)),
        )

    def next_feed_generator_index_part_index(self, *, collection: str, date_utc: str) -> int:
        row = self.conn.execute(
            """
            SELECT MAX(part_index) AS m
            FROM feed_generator_index_parts
            WHERE collection=? AND date_utc=?
            """,
            (str(collection), str(date_utc)),
        ).fetchone()
        if row is None:
            return 0
        m = row["m"]
        try:
            return int(m) + 1 if m is not None else 0
        except Exception:  # noqa: BLE001
            return 0

    def start_feed_generator_index_part(
        self,
        *,
        collection: str,
        date_utc: str,
        part_index: int,
        started_at_utc: str,
    ) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO feed_generator_index_parts(
              collection, date_utc, part_index, status, started_at_utc, finished_at_utc, n_records, last_error
            )
            VALUES (?, ?, ?, 'in_progress', ?, NULL, 0, NULL)
            """,
            (str(collection), str(date_utc), int(part_index), str(started_at_utc)),
        )

    def finish_feed_generator_index_part(
        self,
        *,
        collection: str,
        date_utc: str,
        part_index: int,
        success: bool,
        finished_at_utc: str,
        n_records: int,
        last_error: str | None,
    ) -> None:
        status = "success" if success else "failed"
        self.conn.execute(
            """
            UPDATE feed_generator_index_parts
            SET status=?,
                finished_at_utc=?,
                n_records=?,
                last_error=?
            WHERE collection=? AND date_utc=? AND part_index=?
            """,
            (
                str(status),
                str(finished_at_utc),
                int(n_records),
                last_error,
                str(collection),
                str(date_utc),
                int(part_index),
            ),
        )

    def iter_feed_generator_index_in_progress_parts(
        self, *, collection: str, date_utc: str
    ) -> Iterator[sqlite3.Row]:
        cur = self.conn.execute(
            """
            SELECT collection, date_utc, part_index, status, started_at_utc, finished_at_utc, n_records, last_error
            FROM feed_generator_index_parts
            WHERE collection=? AND date_utc=? AND status='in_progress'
            ORDER BY part_index ASC
            """,
            (str(collection), str(date_utc)),
        )
        yield from cur


@dataclass(frozen=True)
class SnapshotStatusDB:
    path: Path
    conn: sqlite3.Connection

    @staticmethod
    def open(path: Path) -> "SnapshotStatusDB":
        path.parent.mkdir(parents=True, exist_ok=True)
        conn = _connect_sqlite(path)
        db = SnapshotStatusDB(path=path, conn=conn)
        db.init_schema()
        return db

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "SnapshotStatusDB":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        self.close()

    def init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS feed_tasks (
              feed_uri TEXT NOT NULL,
              viewer_mode TEXT NOT NULL,
              status TEXT NOT NULL,
              attempts INTEGER NOT NULL,
              last_error TEXT,
              updated_at_utc TEXT NOT NULL,
              started_at_utc TEXT,
              finished_at_utc TEXT,
              PRIMARY KEY (feed_uri, viewer_mode)
            );
            """
        )
        self.conn.commit()

    def reset_in_progress_to_pending(self, *, updated_at_utc: str) -> int:
        cur = self.conn.execute(
            """
            UPDATE feed_tasks
            SET status='pending', updated_at_utc=?
            WHERE status='in_progress'
            """,
            (updated_at_utc,),
        )
        self.conn.commit()
        return int(cur.rowcount)

    def ensure_tasks(
        self, *, tasks: Sequence[tuple[FeedUri, ViewerMode]], updated_at_utc: str
    ) -> None:
        rows: list[tuple[str, str, str, int, str | None, str, str | None, str | None]] = []
        for feed_uri, viewer_mode in tasks:
            rows.append((str(feed_uri), str(viewer_mode), "pending", 0, None, updated_at_utc, None, None))
        self.conn.executemany(
            """
            INSERT OR IGNORE INTO feed_tasks(
              feed_uri, viewer_mode, status, attempts, last_error, updated_at_utc, started_at_utc, finished_at_utc
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            rows,
        )
        self.conn.commit()

    def counts_by_status(self) -> dict[str, int]:
        cur = self.conn.execute("SELECT status, COUNT(*) AS n FROM feed_tasks GROUP BY status")
        return {str(r["status"]): int(r["n"]) for r in cur.fetchall()}

    def get_task_status(self, *, feed_uri: FeedUri, viewer_mode: ViewerMode) -> str | None:
        row = self.conn.execute(
            "SELECT status FROM feed_tasks WHERE feed_uri=? AND viewer_mode=?",
            (str(feed_uri), str(viewer_mode)),
        ).fetchone()
        if row is None:
            return None
        return str(row["status"])

    def pending_tasks(self, *, max_attempts: int) -> list[tuple[FeedUri, ViewerMode, int]]:
        cur = self.conn.execute(
            """
            SELECT feed_uri, viewer_mode, attempts
            FROM feed_tasks
            WHERE status IN ('pending', 'failed') AND attempts < ?
            ORDER BY attempts ASC, feed_uri ASC
            """,
            (max_attempts,),
        )
        return [(FeedUri(str(r["feed_uri"])), str(r["viewer_mode"]), int(r["attempts"])) for r in cur.fetchall()]

    def mark_in_progress(self, *, feed_uri: FeedUri, viewer_mode: ViewerMode, started_at_utc: str) -> None:
        self.conn.execute(
            """
            UPDATE feed_tasks
            SET status='in_progress',
                attempts=attempts + 1,
                updated_at_utc=?,
                started_at_utc=?
            WHERE feed_uri=? AND viewer_mode=?
            """,
            (started_at_utc, started_at_utc, str(feed_uri), str(viewer_mode)),
        )
        self.conn.commit()

    def mark_done(
        self,
        *,
        feed_uri: FeedUri,
        viewer_mode: ViewerMode,
        success: bool,
        finished_at_utc: str,
        last_error: str | None,
    ) -> None:
        status = "success" if success else "failed"
        self.conn.execute(
            """
            UPDATE feed_tasks
            SET status=?,
                updated_at_utc=?,
                finished_at_utc=?,
                last_error=?
            WHERE feed_uri=? AND viewer_mode=?
            """,
            (status, finished_at_utc, finished_at_utc, last_error, str(feed_uri), str(viewer_mode)),
        )
        self.conn.commit()

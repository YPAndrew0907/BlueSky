from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from bsky_collector_v2.fs_utils import ensure_dir
from bsky_collector_v2.http_client import AsyncHttpClient, HttpRetryConfig, XrpcHosts
from bsky_collector_v2.layout import Layout
from bsky_collector_v2.state import ControlState
from bsky_collector_v2.time_utils import format_utc, now_utc, utc_date_str
from bsky_collector_v2.types import RunId
from bsky_collector_v2.writers import CsvPartWriter

logger = logging.getLogger("bsky_collector_v2.job.hydrate_authors")


_AUTHOR_FIELDS: tuple[str, ...] = (
    "run_id",
    "vantage_id",
    "author_did",
    "handle",
    "display_name",
    "followers_count",
    "follows_count",
    "posts_count",
    "captured_at_utc",
)


@dataclass(frozen=True)
class HydrateAuthorsConfig:
    batch_size: int = 25
    max_authors: int = 50_000


async def run_hydrate_authors(
    *,
    layout: Layout,
    hosts: XrpcHosts,
    run_id: RunId,
    rps: float,
    concurrency: int,
    dry_run: bool,
    cfg: HydrateAuthorsConfig | None = None,
    accept_language: str | None,
    accept_labelers: str | None,
    vantage_id: str,
) -> None:
    cfg = cfg or HydrateAuthorsConfig()
    date_str = utc_date_str(now_utc())
    out_dir = layout.authors_day_dir(date_str)
    out_csv = out_dir / "author_profiles_part_000.csv"
    if dry_run:
        logger.info("dry_run=true: would hydrate authors out=%s", str(out_csv))
        return

    ensure_dir(out_dir)

    started_at_utc = format_utc(now_utc())
    http = AsyncHttpClient(
        hosts=hosts,
        rps=rps,
        retry=HttpRetryConfig(max_retries=1),
        timeout_s=20.0,
        http_stats=None,
        progress=None,
        accept_language=accept_language,
        accept_labelers=accept_labelers,
    )

    writer = CsvPartWriter(out_csv, fieldnames=_AUTHOR_FIELDS)
    hydrated_total = 0

    try:
        with ControlState.open(layout.control_db_path) as control:
            control.start_run(run_id=run_id, job_name="hydrate-authors", started_at_utc=started_at_utc, params={"date": date_str})
            success = False

            try:
                to_hydrate = control.select_authors_to_hydrate(limit=cfg.max_authors)
                logger.info("hydrate-authors start candidates=%s batch_size=%s", len(to_hydrate), cfg.batch_size)

                for i in range(0, len(to_hydrate), cfg.batch_size):
                    batch = to_hydrate[i : i + cfg.batch_size]
                    captured_at_utc = format_utc(now_utc())
                    resp = await http.xrpc_get(
                        endpoint="app.bsky.actor.getProfiles",
                        host=http.hosts.appview_host,
                        method="app.bsky.actor.getProfiles",
                        params={"actors": batch},
                        access_jwt=None,
                        feed_uri=None,
                        timestamp_utc=captured_at_utc,
                    )
                    profiles = resp.data.get("profiles")
                    if not isinstance(profiles, list):
                        continue

                    hydrated: list[str] = []
                    rows: list[dict[str, Any]] = []
                    for p in profiles:
                        if not isinstance(p, dict):
                            continue
                        did = p.get("did")
                        if not isinstance(did, str) or not did:
                            continue
                        hydrated.append(did)
                        rows.append(
                            {
                                "run_id": str(run_id),
                                "vantage_id": str(vantage_id).strip() or "unauth",
                                "author_did": did,
                                "handle": p.get("handle"),
                                "display_name": p.get("displayName"),
                                "followers_count": p.get("followersCount"),
                                "follows_count": p.get("followsCount"),
                                "posts_count": p.get("postsCount"),
                                "captured_at_utc": captured_at_utc,
                            }
                        )

                    writer.write_rows(rows)
                    writer.flush(force_fsync=False)
                    control.mark_authors_hydrated(author_dids=hydrated, hydrated_at_utc=captured_at_utc)
                    control.commit()
                    hydrated_total += len(hydrated)

                success = True
                logger.info("hydrate-authors done hydrated=%s", hydrated_total)
            finally:
                control.finish_run(run_id=run_id, finished_at_utc=format_utc(now_utc()), success=success)
    finally:
        writer.close()
        await http.aclose()

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime


def now_utc() -> datetime:
    return datetime.now(tz=UTC)


def format_utc(dt: datetime) -> str:
    if dt.tzinfo is None:
        raise ValueError("format_utc requires timezone-aware datetime")
    return dt.astimezone(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def utc_date_str(dt: datetime) -> str:
    return dt.astimezone(UTC).date().isoformat()


def utc_hour_str(dt: datetime) -> str:
    # Hour directory name must be zero-padded.
    return f"{dt.astimezone(UTC).hour:02d}"


def floor_to_hour_utc(dt: datetime) -> datetime:
    dt_utc = dt.astimezone(UTC)
    return dt_utc.replace(minute=0, second=0, microsecond=0)


@dataclass(frozen=True)
class SnapshotHour:
    hour_utc: datetime

    @property
    def date_str(self) -> str:
        return utc_date_str(self.hour_utc)

    @property
    def hour_str(self) -> str:
        return utc_hour_str(self.hour_utc)

    @property
    def hour_iso_z(self) -> str:
        return format_utc(self.hour_utc)


# Bluesky Collector v2 (data_v2_full)

Production-grade, crash-resilient, write-as-you-go collector for feed impressions + discovery metadata.

## Hard guarantees

- Writes incrementally to disk under `/Volumes/T9/BlueSky/data_v2_full` (no “write everything at the end”).
- `kill -9` at any time does **not** delete already-written parts/logs/DBs.
- Resume is the default: reruns continue from per-run SQLite state with minimal duplication.
- Fails fast if `--out-base` is missing or not writable (never silently writes elsewhere).
- No secrets are written to logs.

## Output layout (under `--out-base`)

```
metadata/YYYY-MM-DD/
  discovery_sources/
    popular_feed_generators.jsonl
    suggested_feeds.jsonl
    suggested_accounts.jsonl
    suggested_follows_by_actor.jsonl
    onboarding_suggested_starterpacks.jsonl
  feed_catalog.csv
  starterpack_feeds.csv
  starterpack_accounts.csv
  suggested_feeds.csv
  suggested_accounts.csv
  suggested_follows_by_actor.csv

panel/
  panel_v1.csv
  panel_versions/
    panel_v1_YYYY-MM-DD.csv

hourly/YYYY-MM-DD/HH/
  run_manifest.json
  progress.json
  http_stats.csv
  snapshot_status.sqlite
  parts/
    feed_items_part_000.csv
    posts_first_seen_part_000.csv
    post_labels_part_000.csv
    post_metrics_part_000.csv
  logs/
    snapshot.log

wide/YYYY-MM-DD/
  run_manifest.json
  progress.json
  http_stats.csv
  parts/...
  logs/
    wide.log

authors/YYYY-MM-DD/
  author_profiles_part_000.csv

control/
  control_state.db

logs/
  collector.log
  errors.log
```

## Setup

From repo root (`/Volumes/T9/BlueSky`):

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -e .
```

## Auth env file (optional)

Create a file like `auth.env`:

```bash
BSKY_IDENTIFIER=your-handle-or-email
BSKY_APP_PASSWORD=xxxx-xxxx-xxxx-xxxx
BSKY_PDS_HOST=https://bsky.social
```

Never commit this file.

## CLI

Entry point:

```bash
python -m bsky_collector_v2 <subcommand> [global flags] [subcommand flags]
```

Global flags:

- `--out-base /Volumes/T9/BlueSky/data_v2_full`
- `--env-path auth.env` (or set `BSKY_ENV_PATH`)
- `--log-level info|debug`
- `--rps 25`
- `--concurrency 32`
- `--posts-per-feed 100`
- `--time-budget-minutes 55`
- `--feed-time-budget-s 60`
- `--viewer-modes unauth,auth`
- `--accept-language en-US` (or set `BSKY_ACCEPT_LANGUAGE`)
- `--accept-labelers did:plc:...` (or set `BSKY_ACCEPT_LABELERS`)
- `--vantage-id-unauth unauth_enUS` (or set `BSKY_VANTAGE_ID_UNAUTH`)
- `--vantage-id-auth auth_enUS` (or set `BSKY_VANTAGE_ID_AUTH`)
- `--resume` / `--no-resume`
- `--dry-run`

Subcommands:

- `healthcheck`
- `refresh-discovery`
- `build-panel`
- `snapshot-panel` (`--snapshot-hour-utc 2026-02-13T01:00:00Z` optional)
- `wide-sweep` (`--n-feeds 5000`)
- `hydrate-authors` (`--max-authors 50000`, `--batch-size 25`)
- `backfill-interactions` (optional; currently a no-op placeholder)

## Scheduling examples

### Cron (simple)

Hourly snapshots (unauth + auth when env available):

```cron
0 * * * * cd /Volumes/T9/BlueSky && .venv/bin/python -m bsky_collector_v2 snapshot-panel --out-base /Volumes/T9/BlueSky/data_v2_full --env-path /Volumes/T9/BlueSky/auth.env --accept-language en-US --vantage-id-unauth unauth_enUS --vantage-id-auth auth_enUS --viewer-modes unauth,auth --posts-per-feed 100 --concurrency 32 --rps 25 --time-budget-minutes 55
```

Daily discovery + panel build:

```cron
15 0 * * * cd /Volumes/T9/BlueSky && .venv/bin/python -m bsky_collector_v2 refresh-discovery --out-base /Volumes/T9/BlueSky/data_v2_full --accept-language en-US --vantage-id-unauth unauth_enUS --concurrency 32 --rps 25
30 0 * * * cd /Volumes/T9/BlueSky && .venv/bin/python -m bsky_collector_v2 build-panel --out-base /Volumes/T9/BlueSky/data_v2_full --concurrency 32 --rps 25
```

Daily wide sweep (unauth only, shallow):

```cron
0 2 * * * cd /Volumes/T9/BlueSky && .venv/bin/python -m bsky_collector_v2 wide-sweep --out-base /Volumes/T9/BlueSky/data_v2_full --accept-language en-US --vantage-id-unauth unauth_enUS --posts-per-feed 20 --n-feeds 10000 --concurrency 32 --rps 25 --time-budget-minutes 55
```

Daily author hydration:

```cron
0 3 * * * cd /Volumes/T9/BlueSky && .venv/bin/python -m bsky_collector_v2 hydrate-authors --out-base /Volumes/T9/BlueSky/data_v2_full --accept-language en-US --vantage-id-unauth unauth_enUS --max-authors 50000 --batch-size 25 --concurrency 8 --rps 25
```

### launchd (macOS sketch)

Use `StartCalendarInterval` for hourly `snapshot-panel` and daily `refresh-discovery` / `build-panel`. Keep `WorkingDirectory=/Volumes/T9/BlueSky` and run with `.venv/bin/python`.

## Live monitoring (“watch”)

Global logs:

```bash
tail -f /Volumes/T9/BlueSky/data_v2_full/logs/collector.log
tail -f /Volumes/T9/BlueSky/data_v2_full/logs/errors.log
```

Per-hour snapshot logs + progress:

```bash
tail -f /Volumes/T9/BlueSky/data_v2_full/hourly/YYYY-MM-DD/HH/logs/snapshot.log
cat /Volumes/T9/BlueSky/data_v2_full/hourly/YYYY-MM-DD/HH/progress.json
ls -lh /Volumes/T9/BlueSky/data_v2_full/hourly/YYYY-MM-DD/HH/parts/
```

Wide sweep logs + progress:

```bash
tail -f /Volumes/T9/BlueSky/data_v2_full/wide/YYYY-MM-DD/logs/wide.log
cat /Volumes/T9/BlueSky/data_v2_full/wide/YYYY-MM-DD/progress.json
ls -lh /Volumes/T9/BlueSky/data_v2_full/wide/YYYY-MM-DD/parts/
```

## Notes on “popular feeds”

The official “popular feed generators” endpoint may return only ~100–200 feeds. Panel “popular” is defined as the **top feeds by `likeCount` across the discovered feed catalog**, not by requiring 800+ results from the popular endpoint.

## Tests

```bash
make test
```

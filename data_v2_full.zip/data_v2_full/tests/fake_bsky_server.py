from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import parse_qs, urlparse


def _json_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")


@dataclass(frozen=True)
class FakeBskyConfig:
    request_delay_s: float = 0.0


class FakeBskyServer:
    def __init__(self, *, feeds: dict[str, int], cfg: FakeBskyConfig | None = None) -> None:
        self._cfg = cfg or FakeBskyConfig()
        self._feeds = dict(feeds)  # feed_uri -> posts_count

        handler_cls = self._make_handler()
        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)

    def _make_handler(self):  # noqa: ANN201
        feeds = self._feeds
        cfg = self._cfg

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt: str, *args: object) -> None:  # noqa: A003
                # Silence default request logging in tests.
                return

            def _send_json(self, code: int, obj: Any) -> None:
                payload = _json_bytes(obj)
                self.send_response(code)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self) -> None:  # noqa: N802
                if cfg.request_delay_s:
                    time.sleep(cfg.request_delay_s)

                parsed = urlparse(self.path)
                if parsed.path.endswith("/xrpc/app.bsky.feed.getFeed"):
                    qs = parse_qs(parsed.query)
                    feed = (qs.get("feed") or [""])[0]
                    limit_s = (qs.get("limit") or ["50"])[0]
                    try:
                        limit = max(1, min(100, int(limit_s)))
                    except ValueError:
                        limit = 50

                    # Optional auth-required simulation.
                    if "authreq" in feed and not self.headers.get("Authorization"):
                        self._send_json(401, {"error": "AuthRequired", "message": "Authentication required"})
                        return

                    total = int(feeds.get(feed, 0))
                    out = []
                    for i in range(min(limit, total)):
                        author_did = f"did:plc:author{i%5:03d}"
                        post_uri = f"at://{author_did}/app.bsky.feed.post/post{i:06d}"
                        out.append(
                            {
                                "post": {
                                    "uri": post_uri,
                                    "cid": f"cid{i:06d}",
                                    "author": {"did": author_did, "handle": f"user{i%5:03d}.test"},
                                    "record": {"text": f"hello {i}", "createdAt": "2026-02-13T00:00:00Z"},
                                    "indexedAt": "2026-02-13T00:00:00Z",
                                    "likeCount": i,
                                    "repostCount": 0,
                                    "replyCount": 0,
                                    "quoteCount": 0,
                                }
                            }
                        )
                    self._send_json(200, {"feed": out})
                    return

                if parsed.path.endswith("/xrpc/app.bsky.actor.getProfile"):
                    self._send_json(200, {"did": "did:plc:bsky", "handle": "bsky.app"})
                    return

                if parsed.path.endswith("/xrpc/app.bsky.actor.getProfiles"):
                    qs = parse_qs(parsed.query)
                    actors = qs.get("actors") or []
                    profiles = []
                    for did in actors:
                        profiles.append(
                            {
                                "did": did,
                                "handle": did.replace("did:plc:", "") + ".test",
                                "displayName": "Test",
                                "followersCount": 1,
                                "followsCount": 2,
                                "postsCount": 3,
                            }
                        )
                    self._send_json(200, {"profiles": profiles})
                    return

                self._send_json(404, {"error": "NotFound", "message": "not found"})

            def do_POST(self) -> None:  # noqa: N802
                if cfg.request_delay_s:
                    time.sleep(cfg.request_delay_s)

                parsed = urlparse(self.path)
                if parsed.path.endswith("/xrpc/com.atproto.server.createSession"):
                    self._send_json(200, {"accessJwt": "access", "refreshJwt": "refresh"})
                    return
                self._send_json(404, {"error": "NotFound", "message": "not found"})

        return Handler

    @property
    def base_url(self) -> str:
        host, port = self._httpd.server_address
        return f"http://{host}:{port}"

    def start(self) -> None:
        self._thread.start()

    def close(self) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()

    def __enter__(self) -> "FakeBskyServer":
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # noqa: ANN001
        self.close()


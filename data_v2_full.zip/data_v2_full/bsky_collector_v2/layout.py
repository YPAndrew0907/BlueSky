from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from bsky_collector_v2.time_utils import SnapshotHour


@dataclass(frozen=True)
class Layout:
    out_base: Path

    @property
    def metadata_root(self) -> Path:
        return self.out_base / "metadata"

    def metadata_day(self, date_yyyy_mm_dd: str) -> Path:
        return self.metadata_root / date_yyyy_mm_dd

    def discovery_sources_dir(self, date_yyyy_mm_dd: str) -> Path:
        return self.metadata_day(date_yyyy_mm_dd) / "discovery_sources"

    def feed_catalog_csv(self, date_yyyy_mm_dd: str) -> Path:
        return self.metadata_day(date_yyyy_mm_dd) / "feed_catalog.csv"

    def starterpack_feeds_csv(self, date_yyyy_mm_dd: str) -> Path:
        return self.metadata_day(date_yyyy_mm_dd) / "starterpack_feeds.csv"

    @property
    def panel_root(self) -> Path:
        return self.out_base / "panel"

    @property
    def panel_active_csv(self) -> Path:
        return self.panel_root / "panel_v1.csv"

    @property
    def panel_versions_dir(self) -> Path:
        return self.panel_root / "panel_versions"

    def panel_version_csv(self, date_yyyy_mm_dd: str) -> Path:
        return self.panel_versions_dir / f"panel_v1_{date_yyyy_mm_dd}.csv"

    @property
    def hourly_root(self) -> Path:
        return self.out_base / "hourly"

    def hourly_hour_dir(self, hour: SnapshotHour) -> Path:
        return self.hourly_root / hour.date_str / hour.hour_str

    def hourly_manifest_json(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "run_manifest.json"

    def hourly_progress_json(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "progress.json"

    def hourly_http_stats_csv(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "http_stats.csv"

    def hourly_status_sqlite(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "snapshot_status.sqlite"

    def hourly_parts_dir(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "parts"

    def hourly_logs_dir(self, hour: SnapshotHour) -> Path:
        return self.hourly_hour_dir(hour) / "logs"

    def hourly_snapshot_log(self, hour: SnapshotHour) -> Path:
        return self.hourly_logs_dir(hour) / "snapshot.log"

    @property
    def wide_root(self) -> Path:
        return self.out_base / "wide"

    def wide_day_dir(self, date_yyyy_mm_dd: str) -> Path:
        return self.wide_root / date_yyyy_mm_dd

    def wide_manifest_json(self, date_yyyy_mm_dd: str) -> Path:
        return self.wide_day_dir(date_yyyy_mm_dd) / "run_manifest.json"

    def wide_progress_json(self, date_yyyy_mm_dd: str) -> Path:
        return self.wide_day_dir(date_yyyy_mm_dd) / "progress.json"

    def wide_http_stats_csv(self, date_yyyy_mm_dd: str) -> Path:
        return self.wide_day_dir(date_yyyy_mm_dd) / "http_stats.csv"

    def wide_parts_dir(self, date_yyyy_mm_dd: str) -> Path:
        return self.wide_day_dir(date_yyyy_mm_dd) / "parts"

    @property
    def authors_root(self) -> Path:
        return self.out_base / "authors"

    def authors_day_dir(self, date_yyyy_mm_dd: str) -> Path:
        return self.authors_root / date_yyyy_mm_dd

    @property
    def control_root(self) -> Path:
        return self.out_base / "control"

    @property
    def control_db_path(self) -> Path:
        return self.control_root / "control_state.db"

    @property
    def logs_root(self) -> Path:
        return self.out_base / "logs"

    @property
    def global_collector_log(self) -> Path:
        return self.logs_root / "collector.log"

    @property
    def global_errors_log(self) -> Path:
        return self.logs_root / "errors.log"


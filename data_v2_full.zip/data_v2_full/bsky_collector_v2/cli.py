from __future__ import annotations

import argparse
import asyncio
import logging
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from bsky_collector_v2.fs_utils import ensure_dir, ensure_out_base
from bsky_collector_v2.http_client import XrpcHosts
from bsky_collector_v2.layout import Layout
from bsky_collector_v2.logging_utils import LoggingPaths, configure_global_logging
from bsky_collector_v2.logging_utils import add_run_log_file
from bsky_collector_v2.manifest import new_run_id
from bsky_collector_v2.time_utils import SnapshotHour, floor_to_hour_utc, now_utc

DEFAULT_OUT_BASE = Path("/Volumes/T9/BlueSky/data_v2_full")

logger = logging.getLogger("bsky_collector_v2")


@dataclass(frozen=True)
class GlobalArgs:
    out_base: Path
    env_path: Path | None
    log_level: str
    rps: float
    concurrency: int
    posts_per_feed: int
    time_budget_minutes: int
    viewer_modes: tuple[str, ...]
    resume: bool
    dry_run: bool
    appview_host: str
    pds_host: str


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--out-base", type=Path, default=DEFAULT_OUT_BASE)
    common.add_argument("--env-path", type=Path, default=None)
    common.add_argument("--log-level", choices=["info", "debug"], default="info")
    common.add_argument(
        "--appview-host",
        type=str,
        default=os.environ.get("BSKY_APPVIEW_HOST", "https://public.api.bsky.app"),
    )
    common.add_argument(
        "--pds-host",
        type=str,
        default=os.environ.get("BSKY_PDS_HOST", "https://bsky.social"),
    )
    common.add_argument("--rps", type=float, default=25.0)
    common.add_argument("--concurrency", type=int, default=32)
    common.add_argument("--posts-per-feed", type=int, default=100)
    common.add_argument("--time-budget-minutes", type=int, default=55)
    common.add_argument("--viewer-modes", type=str, default="unauth,auth")
    common.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    common.add_argument("--dry-run", action="store_true", default=False)

    p = argparse.ArgumentParser(prog="python -m bsky_collector_v2", parents=[common])

    sub = p.add_subparsers(dest="subcommand", required=True)
    sub.add_parser("healthcheck", parents=[common], add_help=True)
    sub.add_parser("refresh-discovery", parents=[common], add_help=True)
    sub.add_parser("build-panel", parents=[common], add_help=True)
    snap = sub.add_parser("snapshot-panel", parents=[common], add_help=True)
    snap.add_argument(
        "--snapshot-hour-utc",
        type=str,
        default=None,
        help="Optional ISO hour like 2026-02-13T01:00:00Z (defaults to current UTC hour).",
    )
    wide = sub.add_parser("wide-sweep", parents=[common], add_help=True)
    wide.add_argument("--n-feeds", type=int, default=5000)

    hyd = sub.add_parser("hydrate-authors", parents=[common], add_help=True)
    hyd.add_argument("--max-authors", type=int, default=50000)
    hyd.add_argument("--batch-size", type=int, default=25)

    sub.add_parser("backfill-interactions", parents=[common], add_help=True)
    return p


def _parse_global_args(ns: argparse.Namespace) -> GlobalArgs:
    env_path = ns.env_path
    if env_path is None:
        env_var = os.environ.get("BSKY_ENV_PATH")
        if env_var:
            env_path = Path(env_var)

    viewer_modes = tuple(m.strip() for m in str(ns.viewer_modes).split(",") if m.strip())

    return GlobalArgs(
        out_base=ns.out_base,
        env_path=env_path,
        log_level=str(ns.log_level),
        appview_host=str(ns.appview_host),
        pds_host=str(ns.pds_host),
        rps=float(ns.rps),
        concurrency=int(ns.concurrency),
        posts_per_feed=int(ns.posts_per_feed),
        time_budget_minutes=int(ns.time_budget_minutes),
        viewer_modes=viewer_modes,
        resume=bool(ns.resume),
        dry_run=bool(ns.dry_run),
    )


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    g = _parse_global_args(args)

    try:
        check = ensure_out_base(g.out_base)
    except Exception as err:  # noqa: BLE001
        print(f"ERROR: {err}", file=sys.stderr)
        return 2
    layout = Layout(out_base=check.out_base)
    ensure_dir(layout.logs_root)
    ensure_dir(layout.control_root)

    configure_global_logging(
        log_level=g.log_level,
        paths=LoggingPaths(
            collector_log=layout.global_collector_log,
            errors_log=layout.global_errors_log,
        ),
    )

    logger.info("out_base ok path=%s mount=%s", str(check.out_base), str(check.mountpoint))
    logger.info("job start subcommand=%s dry_run=%s resume=%s", args.subcommand, g.dry_run, g.resume)

    hosts = XrpcHosts(appview_host=g.appview_host, pds_host=g.pds_host)

    try:
        match args.subcommand:
            case "healthcheck":
                from bsky_collector_v2.jobs.healthcheck import run_healthcheck

                result = asyncio.run(
                    run_healthcheck(
                        layout=layout,
                        hosts=hosts,
                        env_path=g.env_path,
                        rps=g.rps,
                        dry_run=g.dry_run,
                    )
                )
                logger.info(
                    "healthcheck result out_base_ok=%s control_db_ok=%s unauth_http_ok=%s auth_env_ok=%s auth_session_ok=%s",
                    result.out_base_ok,
                    result.control_db_ok,
                    result.unauth_http_ok,
                    result.auth_env_ok,
                    result.auth_session_ok,
                )
                return 0
            case "refresh-discovery":
                from bsky_collector_v2.jobs.refresh_discovery import run_refresh_discovery

                asyncio.run(
                    run_refresh_discovery(
                        layout=layout,
                        repo_root=Path.cwd(),
                        run_id=new_run_id(),
                        hosts=hosts,
                        rps=g.rps,
                        concurrency=g.concurrency,
                        dry_run=g.dry_run,
                    )
                )
                return 0
            case "build-panel":
                from bsky_collector_v2.jobs.build_panel import run_build_panel

                asyncio.run(
                    run_build_panel(
                        layout=layout,
                        run_id=new_run_id(),
                        hosts=hosts,
                        rps=g.rps,
                        concurrency=g.concurrency,
                        dry_run=g.dry_run,
                    )
                )
                return 0
            case "snapshot-panel":
                from bsky_collector_v2.jobs.snapshot_panel import run_snapshot_panel

                hour_dt = floor_to_hour_utc(now_utc())
                if args.snapshot_hour_utc:
                    from datetime import UTC, datetime

                    raw = str(args.snapshot_hour_utc).strip()
                    if raw.endswith("Z"):
                        raw = raw.removesuffix("Z") + "+00:00"
                    hour_dt = datetime.fromisoformat(raw).astimezone(UTC)
                    hour_dt = floor_to_hour_utc(hour_dt)

                hour = SnapshotHour(hour_utc=hour_dt)
                with add_run_log_file(layout.hourly_snapshot_log(hour), log_level=g.log_level):
                    asyncio.run(
                        run_snapshot_panel(
                            layout=layout,
                            hosts=hosts,
                            env_path=g.env_path,
                            viewer_modes=g.viewer_modes,
                            posts_per_feed=g.posts_per_feed,
                            rps=g.rps,
                            concurrency=g.concurrency,
                            time_budget_minutes=g.time_budget_minutes,
                            resume=g.resume,
                            dry_run=g.dry_run,
                            snapshot_hour_utc=hour_dt,
                        )
                    )
                return 0
            case "wide-sweep":
                from bsky_collector_v2.jobs.wide_sweep import run_wide_sweep

                asyncio.run(
                    run_wide_sweep(
                        layout=layout,
                        hosts=hosts,
                        n_feeds=int(args.n_feeds),
                        posts_per_feed=g.posts_per_feed,
                        rps=g.rps,
                        concurrency=g.concurrency,
                        time_budget_minutes=g.time_budget_minutes,
                        resume=g.resume,
                        dry_run=g.dry_run,
                    )
                )
                return 0
            case "hydrate-authors":
                from bsky_collector_v2.jobs.hydrate_authors import HydrateAuthorsConfig, run_hydrate_authors

                asyncio.run(
                    run_hydrate_authors(
                        layout=layout,
                        hosts=hosts,
                        run_id=new_run_id(),
                        rps=g.rps,
                        concurrency=g.concurrency,
                        dry_run=g.dry_run,
                        cfg=HydrateAuthorsConfig(batch_size=int(args.batch_size), max_authors=int(args.max_authors)),
                    )
                )
                return 0
            case "backfill-interactions":
                logger.warning("backfill-interactions is optional and not implemented yet")
                return 0
            case _:
                logger.error("unknown subcommand: %s", args.subcommand)
                return 2
    except Exception as err:  # noqa: BLE001
        logger.exception("job failed subcommand=%s err=%r", args.subcommand, err)
        return 1

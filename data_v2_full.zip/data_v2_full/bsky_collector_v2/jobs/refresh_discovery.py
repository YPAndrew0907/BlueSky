from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from bsky_collector_v2.fs_utils import ensure_dir
from bsky_collector_v2.http_client import AsyncHttpClient, HttpRetryConfig, XrpcHosts
from bsky_collector_v2.layout import Layout
from bsky_collector_v2.parse_utils import provider_domain_from_service_did
from bsky_collector_v2.state import ControlState
from bsky_collector_v2.time_utils import format_utc, now_utc, utc_date_str
from bsky_collector_v2.types import FeedUri, RunId
from bsky_collector_v2.writers import CsvPartWriter, JsonlWriter

logger = logging.getLogger("bsky_collector_v2.job.refresh_discovery")


@dataclass(frozen=True)
class DiscoveryOutputs:
    day_dir: Path
    sources_dir: Path
    popular_jsonl: Path
    suggested_jsonl: Path
    onboarding_starterpacks_jsonl: Path
    starterpack_search_hits_jsonl: Path
    feed_catalog_csv: Path
    starterpack_feeds_csv: Path


def _outputs(layout: Layout, date_yyyy_mm_dd: str) -> DiscoveryOutputs:
    day_dir = layout.metadata_day(date_yyyy_mm_dd)
    sources = layout.discovery_sources_dir(date_yyyy_mm_dd)
    return DiscoveryOutputs(
        day_dir=day_dir,
        sources_dir=sources,
        popular_jsonl=sources / "popular_feed_generators.jsonl",
        suggested_jsonl=sources / "suggested_feeds.jsonl",
        onboarding_starterpacks_jsonl=sources / "onboarding_starterpacks.jsonl",
        starterpack_search_hits_jsonl=sources / "starterpack_search_hits.jsonl",
        feed_catalog_csv=layout.feed_catalog_csv(date_yyyy_mm_dd),
        starterpack_feeds_csv=layout.starterpack_feeds_csv(date_yyyy_mm_dd),
    )


async def run_refresh_discovery(
    *,
    layout: Layout,
    repo_root: Path,
    run_id: RunId,
    hosts: XrpcHosts,
    rps: float,
    concurrency: int,
    dry_run: bool,
) -> None:
    date_str = utc_date_str(now_utc())
    out = _outputs(layout, date_str)
    if dry_run:
        logger.info("dry_run=true: would write metadata under %s", str(out.day_dir))
        return

    ensure_dir(out.sources_dir)

    started_at_utc = format_utc(now_utc())

    with ControlState.open(layout.control_db_path) as state:
        state.start_run(run_id=run_id, job_name="refresh-discovery", started_at_utc=started_at_utc, params={})
        success = False

        starterpack_writer: CsvPartWriter | None = None
        starterpack_writer = CsvPartWriter(
            out.starterpack_feeds_csv,
            fieldnames=[
                "pack_uri",
                "pack_creator",
                "joinedWeekCount",
                "joinedAllTimeCount",
                "feed_uri",
                "slot_index",
                "captured_at_utc",
                "source",
            ],
            flush_interval_s=2.0,
            fsync_interval_s=10.0,
        )

        try:
            http = AsyncHttpClient(
                hosts=hosts,
                rps=rps,
                retry=HttpRetryConfig(max_retries=2),
                timeout_s=30.0,
                http_stats=None,
                progress=None,
            )
            try:
                captured_at_utc = format_utc(now_utc())

                async with asyncio.TaskGroup() as tg:
                    tg.create_task(
                        _collect_popular(
                            http=http,
                            state=state,
                            out_jsonl=out.popular_jsonl,
                            captured_at_utc=captured_at_utc,
                        )
                    )
                    tg.create_task(
                        _collect_suggested_feeds(
                            http=http,
                            state=state,
                            out_jsonl=out.suggested_jsonl,
                            captured_at_utc=captured_at_utc,
                        )
                    )
                    tg.create_task(
                        _collect_onboarding_starterpacks(
                            http=http,
                            state=state,
                            out_jsonl=out.onboarding_starterpacks_jsonl,
                            starterpack_feeds=starterpack_writer,
                            captured_at_utc=captured_at_utc,
                            concurrency=concurrency,
                        )
                    )

                state.commit()
                _export_feed_catalog_csv(state=state, out_csv=out.feed_catalog_csv)
                logger.info("wrote feed_catalog.csv path=%s", str(out.feed_catalog_csv))
                success = True
            finally:
                await http.aclose()

        finally:
            if starterpack_writer is not None:
                starterpack_writer.close()
            state.finish_run(run_id=run_id, finished_at_utc=format_utc(now_utc()), success=success)


async def _collect_popular(
    *,
    http: AsyncHttpClient,
    state: ControlState,
    out_jsonl: Path,
    captured_at_utc: str,
) -> None:
    cursor: str | None = None
    total = 0
    with JsonlWriter(out_jsonl) as w:
        while True:
            resp = await http.xrpc_get(
                endpoint="app.bsky.unspecced.getPopularFeedGenerators",
                host=http.hosts.appview_host,
                method="app.bsky.unspecced.getPopularFeedGenerators",
                params={"limit": 100, **({"cursor": cursor} if cursor else {})},
                access_jwt=None,
                feed_uri=None,
                timestamp_utc=captured_at_utc,
            )
            feeds = resp.get("feeds")
            if not isinstance(feeds, list):
                raise RuntimeError("popular endpoint missing feeds[]")

            for item in feeds:
                if not isinstance(item, dict):
                    continue
                w.write_obj({"captured_at_utc": captured_at_utc, "source": "popular", "item": item})
                feed_uri = item.get("uri")
                if not isinstance(feed_uri, str) or not feed_uri:
                    continue
                creator_did = _deep_get_str(item, ("creator", "did"))
                service_did = item.get("did") if isinstance(item.get("did"), str) else None
                like_count = item.get("likeCount") if isinstance(item.get("likeCount"), int) else None
                provider_domain = provider_domain_from_service_did(service_did)
                state.upsert_feed_catalog(
                    feed_uri=FeedUri(feed_uri),
                    creator_did=creator_did,
                    service_did=service_did,
                    provider_domain=provider_domain,
                    like_count_last=like_count,
                    discovered_from=["popular_feed_generators"],
                    seen_at_utc=captured_at_utc,
                )
                total += 1

            state.commit()
            cursor = resp.get("cursor") if isinstance(resp.get("cursor"), str) else None
            if not cursor:
                break

    logger.info("popular collected=%s", total)


async def _collect_suggested_feeds(
    *,
    http: AsyncHttpClient,
    state: ControlState,
    out_jsonl: Path,
    captured_at_utc: str,
) -> None:
    methods = (
        "app.bsky.unspecced.getSuggestedFeeds",
        "app.bsky.feed.getSuggestedFeeds",
    )
    cursor: str | None = None
    total = 0

    with JsonlWriter(out_jsonl) as w:
        while True:
            resp: dict[str, Any] | None = None
            last_err: Exception | None = None
            for method in methods:
                try:
                    resp = await http.xrpc_get(
                        endpoint=method,
                        host=http.hosts.appview_host,
                        method=method,
                        params={"limit": 100, **({"cursor": cursor} if cursor else {})},
                        access_jwt=None,
                        feed_uri=None,
                        timestamp_utc=captured_at_utc,
                    )
                    break
                except Exception as err:  # noqa: BLE001
                    last_err = err
                    resp = None
                    continue
            if resp is None:
                logger.warning("suggested feeds unsupported or failed err=%r", last_err)
                return

            feeds = resp.get("feeds") or resp.get("suggestions") or resp.get("suggested")
            if not isinstance(feeds, list):
                logger.warning("suggested feeds response missing feeds[]; skipping")
                return

            for item in feeds:
                if not isinstance(item, dict):
                    continue
                w.write_obj({"captured_at_utc": captured_at_utc, "source": "suggested", "item": item})
                uri = _extract_feed_uri(item)
                if not uri:
                    continue
                creator_did = _deep_get_str(item, ("creator", "did"))
                service_did = item.get("did") if isinstance(item.get("did"), str) else None
                like_count = item.get("likeCount") if isinstance(item.get("likeCount"), int) else None
                provider_domain = provider_domain_from_service_did(service_did)
                state.upsert_feed_catalog(
                    feed_uri=FeedUri(uri),
                    creator_did=creator_did,
                    service_did=service_did,
                    provider_domain=provider_domain,
                    like_count_last=like_count,
                    discovered_from=["suggested_feeds"],
                    seen_at_utc=captured_at_utc,
                )
                total += 1

            state.commit()
            cursor = resp.get("cursor") if isinstance(resp.get("cursor"), str) else None
            if not cursor:
                break

    logger.info("suggested collected=%s", total)


async def _collect_onboarding_starterpacks(
    *,
    http: AsyncHttpClient,
    state: ControlState,
    out_jsonl: Path,
    starterpack_feeds: CsvPartWriter | None,
    captured_at_utc: str,
    concurrency: int,
) -> None:
    methods = (
        "app.bsky.graph.getSuggestedStarterPacks",
        "app.bsky.graph.getStarterPacks",
    )
    resp: dict[str, Any] | None = None
    last_err: Exception | None = None
    for method in methods:
        try:
            resp = await http.xrpc_get(
                endpoint=method,
                host=http.hosts.appview_host,
                method=method,
                params={"limit": 100},
                access_jwt=None,
                feed_uri=None,
                timestamp_utc=captured_at_utc,
            )
            break
        except Exception as err:  # noqa: BLE001
            last_err = err
            resp = None
            continue

    if resp is None:
        logger.warning("starterpacks suggested endpoint unsupported or failed err=%r", last_err)
        return

    packs = resp.get("starterPacks") or resp.get("packs")
    if not isinstance(packs, list):
        logger.warning("starterpacks response missing starterPacks[]; skipping")
        return

    pack_infos: list[dict[str, Any]] = []
    with JsonlWriter(out_jsonl) as w:
        for item in packs:
            if not isinstance(item, dict):
                continue
            w.write_obj({"captured_at_utc": captured_at_utc, "source": "onboarding_suggested", "item": item})
            pack_uri = _extract_pack_uri(item)
            if not pack_uri:
                continue
            pack_infos.append(item)

    sem = asyncio.Semaphore(max(1, min(concurrency, 64)))

    async def hydrate_one(item: dict[str, Any]) -> None:
        pack_uri = _extract_pack_uri(item)
        if not pack_uri:
            return
        async with sem:
            await _hydrate_starterpack(
                http=http,
                state=state,
                starterpack_feeds=starterpack_feeds,
                pack_item=item,
                pack_uri=pack_uri,
                captured_at_utc=captured_at_utc,
            )

    async with asyncio.TaskGroup() as tg:
        for item in pack_infos:
            tg.create_task(hydrate_one(item))

    state.commit()


async def _hydrate_starterpack(
    *,
    http: AsyncHttpClient,
    state: ControlState,
    starterpack_feeds: CsvPartWriter | None,
    pack_item: dict[str, Any],
    pack_uri: str,
    captured_at_utc: str,
) -> None:
    resp = await http.xrpc_get(
        endpoint="app.bsky.graph.getStarterPack",
        host=http.hosts.appview_host,
        method="app.bsky.graph.getStarterPack",
        params={"starterPack": pack_uri},
        access_jwt=None,
        feed_uri=None,
        timestamp_utc=captured_at_utc,
    )
    pack_obj = resp.get("starterPack") if isinstance(resp.get("starterPack"), dict) else resp
    if not isinstance(pack_obj, dict):
        return

    joined_week = pack_item.get("joinedWeekCount") if isinstance(pack_item.get("joinedWeekCount"), int) else None
    joined_all = pack_item.get("joinedAllTimeCount") if isinstance(pack_item.get("joinedAllTimeCount"), int) else None
    pack_creator = _deep_get_str(pack_obj, ("creator", "did")) or _deep_get_str(pack_item, ("creator", "did"))

    feed_uris = _extract_feed_uris(pack_obj)
    for idx, feed_uri in enumerate(feed_uris):
        state.upsert_feed_catalog(
            feed_uri=FeedUri(feed_uri),
            creator_did=None,
            service_did=None,
            provider_domain=None,
            like_count_last=None,
            discovered_from=["onboarding_starterpacks"],
            seen_at_utc=captured_at_utc,
        )
        if starterpack_feeds is not None:
            starterpack_feeds.write_rows(
                [
                    {
                        "pack_uri": pack_uri,
                        "pack_creator": pack_creator,
                        "joinedWeekCount": joined_week,
                        "joinedAllTimeCount": joined_all,
                        "feed_uri": feed_uri,
                        "slot_index": idx,
                        "captured_at_utc": captured_at_utc,
                        "source": "onboarding_suggested",
                    }
                ]
            )


def _deep_get_str(obj: Any, path: Iterable[str]) -> str | None:
    cur: Any = obj
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    if isinstance(cur, str) and cur:
        return cur
    return None


def _extract_feed_uri(item: dict[str, Any]) -> str | None:
    uri = item.get("uri")
    if isinstance(uri, str) and uri:
        return uri
    feed = item.get("feed")
    if isinstance(feed, dict):
        uri2 = feed.get("uri")
        if isinstance(uri2, str) and uri2:
            return uri2
    return None


def _extract_pack_uri(item: dict[str, Any]) -> str | None:
    uri = item.get("uri")
    if isinstance(uri, str) and uri:
        return uri
    starter_pack = item.get("starterPack")
    if isinstance(starter_pack, dict):
        uri2 = starter_pack.get("uri")
        if isinstance(uri2, str) and uri2:
            return uri2
    return None


def _extract_feed_uris(obj: Any) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()

    def visit(x: Any) -> None:
        if isinstance(x, dict):
            uri = x.get("uri")
            if isinstance(uri, str):
                _maybe_add(uri)
            for v in x.values():
                visit(v)
        elif isinstance(x, list):
            for v in x:
                visit(v)

    def _maybe_add(uri: str) -> None:
        if "/app.bsky.feed.generator/" not in uri:
            return
        if uri in seen:
            return
        seen.add(uri)
        out.append(uri)

    visit(obj)
    return out


def _export_feed_catalog_csv(*, state: ControlState, out_csv: Path) -> None:
    tmp = out_csv.with_name(out_csv.name + ".tmp")
    ensure_dir(out_csv.parent)
    with open(tmp, "w", encoding="utf-8", newline="") as f:
        import csv

        w = csv.writer(f)
        w.writerow(
            [
                "feed_uri",
                "creator_did",
                "service_did",
                "provider_domain",
                "like_count_last",
                "discovered_from_json",
                "first_seen_utc",
                "last_seen_utc",
                "last_hydrated_utc",
            ]
        )
        for row in state.iter_feed_catalog():
            w.writerow(
                [
                    row["feed_uri"],
                    row["creator_did"],
                    row["service_did"],
                    row["provider_domain"],
                    row["like_count_last"],
                    row["discovered_from"],
                    row["first_seen_utc"],
                    row["last_seen_utc"],
                    row["last_hydrated_utc"],
                ]
            )
        f.flush()

    tmp.replace(out_csv)

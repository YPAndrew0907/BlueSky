from __future__ import annotations

import logging
from dataclasses import dataclass

from bsky_collector_v2.env import AuthEnv
from bsky_collector_v2.http_client import AsyncHttpClient, HttpError
from bsky_collector_v2.time_utils import format_utc, now_utc

logger = logging.getLogger("bsky_collector_v2.session")


@dataclass(frozen=True)
class SessionTokens:
    access_jwt: str
    refresh_jwt: str | None


async def create_session(http: AsyncHttpClient, *, env: AuthEnv) -> SessionTokens:
    # Never log token values.
    ts = format_utc(now_utc())
    resp = await http.xrpc_post(
        endpoint="com.atproto.server.createSession",
        host=env.pds_host,
        method="com.atproto.server.createSession",
        json_body={"identifier": env.identifier, "password": env.app_password},
        access_jwt=None,
        timestamp_utc=ts,
    )
    access = resp.get("accessJwt")
    refresh = resp.get("refreshJwt")
    if not isinstance(access, str) or not access:
        raise RuntimeError("createSession did not return accessJwt")
    refresh_out = refresh if isinstance(refresh, str) and refresh else None
    return SessionTokens(access_jwt=access, refresh_jwt=refresh_out)


async def refresh_session(http: AsyncHttpClient, *, pds_host: str, refresh_jwt: str) -> SessionTokens:
    ts = format_utc(now_utc())
    resp = await http.xrpc_post(
        endpoint="com.atproto.server.refreshSession",
        host=pds_host,
        method="com.atproto.server.refreshSession",
        json_body=None,
        access_jwt=refresh_jwt,
        timestamp_utc=ts,
    )
    access = resp.get("accessJwt")
    refresh = resp.get("refreshJwt")
    if not isinstance(access, str) or not access:
        raise RuntimeError("refreshSession did not return accessJwt")
    refresh_out = refresh if isinstance(refresh, str) and refresh else None
    return SessionTokens(access_jwt=access, refresh_jwt=refresh_out)


def is_auth_required_error(err: HttpError) -> bool:
    if err.status_code in (401, 403):
        return True
    msg = str(err).lower()
    return ("auth" in msg and "required" in msg) or ("authentication" in msg and "required" in msg)


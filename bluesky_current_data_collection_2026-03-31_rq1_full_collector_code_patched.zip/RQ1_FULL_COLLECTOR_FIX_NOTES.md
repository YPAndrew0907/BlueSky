# RQ1 full collector targeted fixes

This patch keeps the existing collector structure intact and only fixes the four issues identified in review.

## What changed

1. **Micro5 appearance scan fixed**
   - `backfill_rq1_factors._iter_matching_appearances()` now scans:
     - `hourly/**/feed_items_part_*.csv`
     - `wide/**/feed_items_part_*.csv`
     - `micro5/**/feed_items_part_*.csv`
     - `effective_csv/timeseries/micro5/**/feed_items.csv`
   - Raw `micro5` rows and flattened `effective_csv/timeseries/micro5` rows are deduplicated so the same appearance is not double-counted.

2. **Pairwise relationship blow-up fixed without shrinking graph lanes too aggressively**
   - Full pairwise `getRelationships` is now limited to a focused core actor set:
     - `surface_author`
     - `surface_reason_actor`
     - `feed_creator_repo`
     - `post_author`
     - `quote_author`
     - `thread_actor`
   - The broader graph collection lanes remain intact:
     - actor profiles
     - followers / follows first-hop graph
     - follow-record lane
     - author feed / actor feeds / lists / starter packs / labelers

3. **`post_author_did` summary bug fixed**
   - Summary rows now use an in-memory `post_author_by_post` map captured during post hydration.
   - This removes the previous fragile read-back of `post_views_part_000.csv` before writer close/flush.

4. **Resolved-PDS path is now testable end-to-end**
   - `DidResolver` now supports an optional environment override:
     - `BSKY_PLC_DIRECTORY_BASE`
   - This keeps production defaults unchanged while enabling deterministic local integration tests.

## Files changed

- `bsky_collector_v2/jobs/backfill_rq1_factors.py`
- `bsky_collector_v2/did_resolver.py`
- `tests/test_rq1_factor_backfill.py`
- `tests/fake_bsky_rq1_server.py`

## Local verification run

Executed locally after patching:

- `python -m compileall -q bsky_collector_v2 tests`
- `pytest -vv tests/test_rq1_factor_backfill.py::test_iter_matching_appearances_prefers_micro5_and_dedupes_effective_export`
- `pytest -vv tests/test_rq1_factor_backfill.py::test_iter_matching_appearances_supports_effective_micro5_without_raw_parts`
- `pytest -vv tests/test_rq1_factor_backfill.py::test_backfill_rq1_factors_full_integration`
- `pytest -vv tests/test_rq1_factor_backfill.py::test_backfill_rq1_factors_resolve_pds_endpoints_with_local_plc_override`
- `pytest -vv tests/test_state.py tests/test_wide_sweep_author_labels.py tests/test_snapshot_panel_discovery_quirks.py tests/test_integration.py::test_hydrate_authors_writes_artifacts tests/test_integration.py::test_crash_resume_index_feed_generators`

The targeted tests passed in this environment.

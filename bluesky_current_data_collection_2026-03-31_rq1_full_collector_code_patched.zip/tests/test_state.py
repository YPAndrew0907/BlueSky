from __future__ import annotations

from pathlib import Path

from bsky_collector_v2.state import ControlState
from bsky_collector_v2.types import FeedUri, PostUri
from bsky_collector_v2.time_utils import format_utc, now_utc


def test_control_state_wal_and_post_registry(tmp_path: Path) -> None:
    db_path = tmp_path / "control" / "control_state.db"
    ts = format_utc(now_utc())

    with ControlState.open(db_path) as s:
        row = s.conn.execute("PRAGMA journal_mode;").fetchone()
        assert row is not None
        assert str(row[0]).lower() == "wal"

        posts = [PostUri("at://did:plc:abc/app.bsky.feed.post/1"), PostUri("at://did:plc:abc/app.bsky.feed.post/1")]
        s.upsert_post_registry_many(post_uris=posts, seen_at_utc=ts)
        s.commit()

        row2 = s.conn.execute(
            "SELECT seen_count, first_written FROM post_registry WHERE post_uri=?",
            (str(posts[0]),),
        ).fetchone()
        assert row2 is not None
        assert int(row2["seen_count"]) == 2
        assert int(row2["first_written"]) == 0

        not_written = s.select_not_written(post_uris=[posts[0]])
        assert not_written == [posts[0]]

        s.mark_first_written(post_uris=not_written)
        s.commit()

        not_written2 = s.select_not_written(post_uris=[posts[0]])
        assert not_written2 == []




def test_control_state_interaction_and_feed_hydration_helpers(tmp_path: Path) -> None:
    db_path = tmp_path / "control" / "control_state.db"
    ts = format_utc(now_utc())
    post = PostUri("at://did:plc:abc/app.bsky.feed.post/2")

    with ControlState.open(db_path) as s:
        s.upsert_post_registry_many(post_uris=[post], seen_at_utc=ts)
        s.ensure_post_interaction_tasks(post_uris=[post], enqueued_at_utc=ts)
        s.upsert_feed_catalog(
            feed_uri=FeedUri("at://did:plc:feed/app.bsky.feed.generator/test"),
            creator_did="did:plc:feed",
            service_did="did:web:example.com",
            provider_domain="example.com",
            like_count_last=1,
            discovered_from=["test"],
            seen_at_utc=ts,
        )
        s.commit()

        selected_posts = s.select_posts_to_backfill(limit=10)
        assert selected_posts == [str(post)]

        s.mark_posts_interactions_hydrated(post_uris=[post], hydrated_at_utc=ts)
        s.commit()
        selected_posts_after = s.select_posts_to_backfill(limit=10)
        assert selected_posts_after == []

        selected_feeds = s.select_feed_generators_to_hydrate(limit=10)
        assert selected_feeds == ["at://did:plc:feed/app.bsky.feed.generator/test"]

        s.mark_feed_generators_hydrated(
            feed_uris=[FeedUri("at://did:plc:feed/app.bsky.feed.generator/test")],
            hydrated_at_utc=ts,
        )
        s.commit()
        selected_feeds_after = s.select_feed_generators_to_hydrate(limit=10)
        assert selected_feeds_after == []
